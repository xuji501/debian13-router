# 变更记录

## V1.0.1 — 2026年10月21日

### 新增
- **出厂模板机制**：`install.sh --factory` 用 `factory/rootfs/` 完全复刻模板机配置（PKI、VPN 账号、拨号端隧道、防火墙策略、DHCP）
- `--version` 参数；页脚版权与版本号（起点火箭开发 · 2026年10月21日 · V1.0.1）
- DEB 包与 ISO 构建脚本，形成 tar.gz / deb / ISO 三种发行形态
- OpenVPN 客户端：导入 `.ovpn`、导出 `.ovpn`、固定隧道 IP
- OpenVPN 服务端：路由推送设置（内网/全流量/出向隧道远端网段/自定义）
- 虚拟专网：在线客户端实时列表、踢下线、启停、历史记录
- 防火墙：VPN 客户端网段出隧道的 SNAT + 转发放行

### 修复
- 全新安装时 PPP ip-up/ip-down 钩子渲染参数不足导致安装中断（模板需 5 个参数，原传 3 个）
- 出向隧道「全流量」抢走默认路由，使拨入客户端断网（未勾选时自动加 `pull-filter ignore redirect-gateway`）
- 拨入客户端访问出向隧道远端内网不通（补隧道口 masquerade + forward accept）
- OpenVPN 证书缺 EKU 导致客户端 `VERIFY KU ERROR`（签发补齐 + 存量自愈）
- pptpd 配置变更未触发服务重载
- WAN 口 8080 被硬编码规则拦截
- 模板网卡名 / LAN 网段与新机不一致时的自动适配

## V1.0 — 2026年10月19日

- 首个可安装版本：NAT/DNS/DHCP/防火墙/流量统计/五协议 VPN/Web 管理
- 配置驱动改造：所有网络参数集中于 `/etc/routeweb/config.json`
- 一键安装脚本（向导 / 无人值守 / dry-run / 卸载）
