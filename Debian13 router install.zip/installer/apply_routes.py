#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RouteWeb 静态路由开机恢复脚本。
读取 /opt/routeweb/state.json 中的 static_routes, 用 `ip route replace` 重新下发。
由 systemd 单元 routeweb-routes.service 在 network-online 后调用。
"""
import json
import os
import subprocess

STATE_FILE = '/opt/routeweb/state.json'


def is_ip(s):
    import re
    if not re.match(r'^(\d{1,3}\.){3}\d{1,3}$', s or ''):
        return False
    return all(0 <= int(x) <= 255 for x in s.split('.'))


def is_cidr(s):
    if '/' not in (s or ''):
        return False
    ip, _, mask = s.partition('/')
    return is_ip(ip) and mask.isdigit() and 0 <= int(mask) <= 32


def run(args):
    try:
        subprocess.run(args, capture_output=True, text=True, timeout=10)
    except Exception:
        pass


def main():
    if not os.path.exists(STATE_FILE):
        return
    try:
        with open(STATE_FILE) as f:
            s = json.load(f)
    except Exception:
        return
    for r in s.get('static_routes', []):
        dest = r.get('dest', '')
        if not is_cidr(dest):
            continue
        args = ['ip', 'route', 'replace', dest]
        if r.get('gw') and is_ip(r['gw']):
            args += ['via', r['gw']]
        if r.get('dev'):
            args += ['dev', r['dev']]
        run(args)


if __name__ == '__main__':
    main()
