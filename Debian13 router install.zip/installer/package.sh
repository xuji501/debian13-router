#!/bin/bash
# 打包为可分发的安装包: ../dist/routeweb-gateway-<版本>.tar.gz
# Linux/macOS 可直接运行; Windows 用 build_release.py(它同时产出 deb 与校验清单)
set -euo pipefail
cd "$(dirname "$0")"
VER=$(grep -m1 '^VERSION=' install.sh | cut -d'"' -f2)
NAME="routeweb-gateway-$VER"
OUT="../dist"
mkdir -p "$OUT"
rm -rf "$OUT/$NAME" "$OUT/$NAME.tar.gz" "$OUT/$NAME.tar.gz.sha256"
mkdir -p "$OUT/$NAME"
cp install.sh build_iso.sh routeweb.py apply_routes.py \
   config.sample README.md RELEASE.md CHANGELOG.md "$OUT/$NAME/"
[ -d factory ] && cp -a factory "$OUT/$NAME/"
chmod +x "$OUT/$NAME/install.sh" "$OUT/$NAME/build_iso.sh"
( cd "$OUT" && tar czf "$NAME.tar.gz" "$NAME" \
  && sha256sum "$NAME.tar.gz" > "$NAME.tar.gz.sha256" )
rm -rf "$OUT/$NAME"
echo "已生成: $OUT/$NAME.tar.gz"
ls -lh "$OUT/$NAME.tar.gz"
cat "$OUT/$NAME.tar.gz.sha256"
