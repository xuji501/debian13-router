# 变更记录

## 文档 — 2026年10月22日

### 新增
- **使用说明书 V1.0.2 随包交付**：`RouteWeb网关使用说明书.docx` 打进 tar.gz 与 deb 包，解压即可见
- 说明书新增**第二章 全新部署与安装**：适用环境、交付文件清单、校验解压、三种安装方式（出厂模板 / 向导 / 无人值守）、
  全新路由标准部署八步、安装后检查、卸载与回退
- 说明书新增**第九章 IPv6 全功能**：总开关、WAN 接入（SLAAC / DHCPv6 / 静态）、LAN 前缀、DHCPv6 + RA、
  NAT66、双栈防火墙与端口转发、IPv6 静态路由、用 IPv6 访问管理页、仪表盘状态卡、常见问题
- 说明书新增**第十二章 配置备份与恢复**：立即备份、备份内容清单、下载/恢复/删除、上传恢复（8MB 上限与校验）、
  自动备份（systemd 定时器）、命令行备份、安全提示
- 同步更新：能力表、防火墙「与 IPv6 的关系」、网络工具「诊断 IPv6」、注意事项 14.7、故障排查增 7 条、
  附录 B 端口清单（DHCPv6 546/547、ICMPv6、OSPFv3）、附录 C 名词（SLAAC / RA / NAT66 / DHCPv6 有状态）
- 文档结构由 13 章扩为 **16 章 + 3 附录**，小节号全量重排

## V1.0.1 — 2026年10月21日

### 新增
- **出厂模板机制**：`install.sh --factory` 用 `factory/rootfs/` 完全复刻模板机配置（PKI、VPN 账号、拨号端隧道、防火墙策略、DHCP）
- `--version` 参数；页脚版权与版本号（起点火箭开发 · 2026年10月21日 · V1.0.1）
- DEB 包与 ISO 构建脚本，形成 tar.gz / deb / ISO 三种发行形态
- OpenVPN 客户端：导入 `.ovpn`、导出 `.ovpn`、固定隧道 IP
- OpenVPN 服务端：路由推送设置（内网/全流量/出向隧道远端网段/自定义）
- 虚拟专网：在线客户端实时列表、踢下线、启停、历史记录
- 防火墙：VPN 客户端网段出隧道的 SNAT + 转发放行
- **WireGuard 支持多客户端 + 监听端口可指定 + 客户端可编辑**：虚拟专网 → WireGuard 新增
  「监听端口 / 客户端接入地址」表单（端口 1-65535，默认 51820；接入地址可填域名，留空取 WAN IP）；
  客户端可添加多个，地址留空自动分配、可勾选由本机生成密钥对（页面直接给出含私钥的完整配置）；
  每个客户端可编辑（名称/公钥/服务端 AllowedIPs/保活/客户端 AllowedIPs/PSK/备注），
  仅改地址等走运行时同步不打断其它客户端，PSK 变更才重载服务；
  `wg0.conf` 的 ListenPort、客户端配置的 Endpoint、防火墙 UDP 放行三处同步；
  端口被 Web 管理页占用时拒绝保存，服务起不来时自动回滚
- **OpenVPN 服务端监听端口可编辑 + 协议可选 UDP/TCP**：虚拟专网 → OpenVPN 新增「监听端口 / 协议」
  表单（端口 1-65535，默认 1194；协议 UDP / TCP 二选一），保存后立即重载；
  `server.conf` 的 port/proto、签发的 `.ovpn` 的 `remote`/`proto`、防火墙放行规则三处同步；
  端口被 Web 管理页占用时拒绝保存；服务起不来时自动回滚到原端口/协议
- **OSPF 动态路由（FRR / ospfd）**：网络配置页新增 OSPF 卡片 —— 一键安装 FRR、启用开关、
  Router-ID、宣告网段（网段 + 区域）、被动接口、重分发（直连 / 静态 / 发布默认路由）、
  OSPF 邻居表与学习到的路由；启用后 `input` 链自动放行 IP 协议 89；
  发行版依赖与出厂模板均纳入 `frr`
- **IPv6 全功能支持**：网络配置页新增 IPv6 卡片 —— 总开关、WAN 接入方式（关闭 / SLAAC /
  DHCPv6 / 静态）、WAN 静态地址+网关+DNS、LAN 地址前缀、DHCPv6+RA（无状态 SLAAC /
  有状态地址池、RA 有效期、下发 DNS）、NAT66；保存时通过 NetworkManager 双栈下发
  （`ipv6.method` auto/dhcp/manual/disabled，失败自动回滚），内核 `forwarding` 与
  `accept_ra=2` 持久化到 `/etc/sysctl.d/`；防火墙按协议族区分 IPv4/IPv6/双栈：
  ICMPv6、DHCPv6（546/547）、OSPFv3（协议 89）自动放行，端口转发支持 `dnat ip6`，
  拒绝规则支持 `ip6 saddr` + `ipv6-icmp`；dnsmasq 生成 `enable-ra` 与 v6 `dhcp-range`；
  静态路由按目标地址自动选 `ip route` / `ip -6 route`；仪表盘新增 IPv6 状态卡
- **配置备份与恢复**：新增「备份恢复」页 —— 立即备份（可加说明）、备份列表（时间/大小/
  说明/版本）、下载（`/backup-download`，字节级原样）、删除、上传恢复（`.tar.gz`，
  上限 8MB）、自动备份（systemd timer，每天指定时刻，可设保留份数）；
  备份内容含 state/auth/config、五协议 VPN 配置与 PKI 私钥、防火墙、dnsmasq、FRR、
  IPv6 sysctl；单份约 40KB，权限 600（目录 700）；归档路径白名单校验（拒绝穿越/
  绝对路径/链接/设备），恢复后自动重载 dnsmasq/nft/静态路由/OSPF/IPv6 sysctl；
  另提供 `routeweb.py --backup [说明]` 命令行备份入口（供 timer 调用）

### 修复
- 全新安装时 PPP ip-up/ip-down 钩子渲染参数不足导致安装中断（模板需 5 个参数，原传 3 个）
- 出向隧道「全流量」抢走默认路由，使拨入客户端断网（未勾选时自动加 `pull-filter ignore redirect-gateway`）
- 拨入客户端访问出向隧道远端内网不通（补隧道口 masquerade + forward accept）
- OpenVPN 证书缺 EKU 导致客户端 `VERIFY KU ERROR`（签发补齐 + 存量自愈）
- pptpd 配置变更未触发服务重载
- WAN 口 8080 被硬编码规则拦截
- 模板网卡名 / LAN 网段与新机不一致时的自动适配

## V1.0 — 2026年10月19日

- 首个可安装版本：NAT/DNS/DHCP/防火墙/流量统计/五协议 VPN/Web 管理
- 配置驱动改造：所有网络参数集中于 `/etc/routeweb/config.json`
- 一键安装脚本（向导 / 无人值守 / dry-run / 卸载）
